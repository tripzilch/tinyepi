EPIHYPERDERPFLARDIOIDS

after symbol 2525, 
aint gonna need to load, write no code
everything you think, do and say
is in the streams that you watch today (oh oh oh)

We find this code is very much alive. They are epi. They are hyper. They are derp. They are flardioids.

Epihyperderpflardioids is the name I have given to a large family of symmetrical loopy shapes, based on sine waves and rotations, reminiscent of the mathematical toy game "Spirograph", but also different. I studied them extensively, but don't claim to understand them fully, yet. I hope you enjoy them as much as I do.

These 365 Epihyperderpflardioids were generated for FXhash's one year anniversary.
